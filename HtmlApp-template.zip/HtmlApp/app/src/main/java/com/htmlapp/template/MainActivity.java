package com.htmlapp.template;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.AlertDialog;
import android.app.PendingIntent;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.GeolocationPermissions;
import android.webkit.JavascriptInterface;
import android.webkit.JsPromptResult;
import android.webkit.JsResult;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.Toast;
import androidx.webkit.WebViewAssetLoader;
import androidx.webkit.WebViewCompat;
import androidx.webkit.WebViewFeature;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;

public class MainActivity extends Activity {
    static final String ORIGIN = "https://appassets.androidplatform.net";
    static final String HOME = ORIGIN + "/www/index.html";
    static final int REQ_FILE = 1, REQ_SAVE = 2, REQ_PERM = 3;

    private WebView web;
    private String bridgeJs = "";
    private boolean docStart = false;

    private ValueCallback<Uri[]> filePathCb;
    private Uri cameraUri;
    private byte[] pendingSaveData;
    private Runnable afterPerm;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        setContentView(web);

        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setUseWideViewPort(true);
        s.setTextZoom(100); // system font size must not change the app's look
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setGeolocationEnabled(true);

        bridgeJs = readAsset("bridge.js");
        web.addJavascriptInterface(new Bridge(), "AndroidBridge");
        if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
            WebViewCompat.addDocumentStartJavaScript(web, bridgeJs, new HashSet<>(Arrays.asList(ORIGIN)));
            docStart = true;
        }

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                return loader.shouldInterceptRequest(r.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                String sch = u.getScheme() == null ? "" : u.getScheme();
                if ((sch + "://" + u.getHost()).equals(ORIGIN)) return false;
                if (sch.equals("blob") || sch.equals("data") || sch.equals("about")) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception ignored) { }
                return true;
            }

            @Override
            public void onPageStarted(WebView v, String url, android.graphics.Bitmap f) {
                if (!docStart) v.evaluateJavascript(bridgeJs, null);
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (filePathCb != null) filePathCb.onReceiveValue(null);
                filePathCb = cb;

                final Intent pick = new Intent(Intent.ACTION_GET_CONTENT);
                pick.addCategory(Intent.CATEGORY_OPENABLE);
                pick.setType("*/*"); // never grey-out backup files like .json
                pick.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, p.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE);

                boolean wantsImage = false;
                String[] acc = p.getAcceptTypes();
                List<String> mimes = new ArrayList<>();
                int nonEmpty = 0;
                if (acc != null) {
                    for (String a : acc) {
                        if (a == null || a.trim().isEmpty()) continue;
                        nonEmpty++;
                        if (a.contains("/")) mimes.add(a.trim());
                        if (a.contains("image")) wantsImage = true;
                    }
                }
                if (!mimes.isEmpty() && mimes.size() == nonEmpty) {
                    pick.putExtra(Intent.EXTRA_MIME_TYPES, mimes.toArray(new String[0]));
                }
                final boolean capture = p.isCaptureEnabled();
                final boolean withCamera = wantsImage || capture;
                if (withCamera) {
                    ensure(Arrays.asList(Manifest.permission.CAMERA), () -> launchChooser(pick, has(Manifest.permission.CAMERA), capture));
                } else {
                    launchChooser(pick, false, false);
                }
                return true;
            }

            @Override
            public boolean onJsAlert(WebView v, String url, String msg, final JsResult r) {
                new AlertDialog.Builder(MainActivity.this).setMessage(msg).setCancelable(false)
                        .setPositiveButton(android.R.string.ok, (d, w) -> r.confirm()).show();
                return true;
            }

            @Override
            public boolean onJsConfirm(WebView v, String url, String msg, final JsResult r) {
                new AlertDialog.Builder(MainActivity.this).setMessage(msg).setCancelable(false)
                        .setPositiveButton(android.R.string.ok, (d, w) -> r.confirm())
                        .setNegativeButton(android.R.string.cancel, (d, w) -> r.cancel()).show();
                return true;
            }

            @Override
            public boolean onJsPrompt(WebView v, String url, String msg, String def, final JsPromptResult r) {
                final EditText et = new EditText(MainActivity.this);
                et.setText(def);
                new AlertDialog.Builder(MainActivity.this).setMessage(msg).setView(et).setCancelable(false)
                        .setPositiveButton(android.R.string.ok, (d, w) -> r.confirm(et.getText().toString()))
                        .setNegativeButton(android.R.string.cancel, (d, w) -> r.cancel()).show();
                return true;
            }

            @Override
            public void onPermissionRequest(final PermissionRequest req) {
                runOnUiThread(() -> {
                    List<String> need = new ArrayList<>();
                    for (String r : req.getResources()) {
                        if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(r)) need.add(Manifest.permission.CAMERA);
                        if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r)) need.add(Manifest.permission.RECORD_AUDIO);
                    }
                    ensure(need, () -> {
                        boolean ok = true;
                        for (String p : need) if (!has(p)) ok = false;
                        if (ok) req.grant(req.getResources()); else req.deny();
                    });
                });
            }

            @Override
            public void onGeolocationPermissionsShowPrompt(final String origin, final GeolocationPermissions.Callback cb) {
                ensure(Arrays.asList(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION),
                        () -> cb.invoke(origin, has(Manifest.permission.ACCESS_FINE_LOCATION) || has(Manifest.permission.ACCESS_COARSE_LOCATION), false));
            }
        });

        web.loadUrl(HOME);
    }

    // ---------- helpers ----------
    private String readAsset(String name) {
        try (InputStream in = getAssets().open(name)) {
            ByteArrayOutputStream o = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) o.write(buf, 0, n);
            return o.toString("UTF-8");
        } catch (Exception e) { return ""; }
    }

    private boolean has(String p) {
        return Build.VERSION.SDK_INT < 23 || checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED;
    }

    private void ensure(List<String> perms, Runnable after) {
        if (Build.VERSION.SDK_INT < 23) { after.run(); return; }
        List<String> need = new ArrayList<>();
        for (String p : perms) if (checkSelfPermission(p) != PackageManager.PERMISSION_GRANTED) need.add(p);
        if (need.isEmpty()) { after.run(); return; }
        afterPerm = after;
        requestPermissions(need.toArray(new String[0]), REQ_PERM);
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        Runnable r = afterPerm;
        afterPerm = null;
        if (r != null) r.run();
    }

    private void launchChooser(Intent pick, boolean withCamera, boolean captureOnly) {
        Intent cam = null;
        cameraUri = null;
        if (withCamera) {
            try {
                ContentValues cv = new ContentValues();
                cv.put(MediaStore.Images.Media.DISPLAY_NAME, "IMG_" + System.currentTimeMillis() + ".jpg");
                cv.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
                cameraUri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv);
                cam = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                cam.putExtra(MediaStore.EXTRA_OUTPUT, cameraUri);
            } catch (Exception e) { cam = null; cameraUri = null; }
        }
        Intent launch;
        if (cam != null && captureOnly) {
            launch = cam;
        } else {
            launch = Intent.createChooser(pick, "Select file");
            if (cam != null) launch.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{cam});
        }
        try {
            startActivityForResult(launch, REQ_FILE);
        } catch (Exception e) {
            if (filePathCb != null) filePathCb.onReceiveValue(null);
            filePathCb = null;
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_FILE) {
            Uri[] out = null;
            if (res == RESULT_OK) {
                if (data != null && data.getClipData() != null) {
                    ClipData cd = data.getClipData();
                    out = new Uri[cd.getItemCount()];
                    for (int i = 0; i < out.length; i++) out[i] = cd.getItemAt(i).getUri();
                } else if (data != null && data.getData() != null) {
                    out = new Uri[]{data.getData()};
                } else if (cameraUri != null) {
                    out = new Uri[]{cameraUri};
                }
            }
            if (cameraUri != null && (out == null || !cameraUri.equals(out[0]))) {
                try { getContentResolver().delete(cameraUri, null, null); } catch (Exception ignored) { }
            }
            cameraUri = null;
            if (filePathCb != null) filePathCb.onReceiveValue(out);
            filePathCb = null;
        } else if (req == REQ_SAVE) {
            boolean ok = false;
            if (res == RESULT_OK && data != null && data.getData() != null && pendingSaveData != null) {
                try (OutputStream os = getContentResolver().openOutputStream(data.getData())) {
                    os.write(pendingSaveData);
                    os.flush();
                    ok = true;
                } catch (Exception e) { ok = false; }
            }
            pendingSaveData = null;
            Toast.makeText(this, ok ? "فایل ذخیره شد" : "ذخیره انجام نشد", Toast.LENGTH_SHORT).show();
            web.evaluateJavascript("window.__onSaveResult&&window.__onSaveResult(" + ok + ")", null);
        }
    }

    @Override
    public void onBackPressed() {
        web.evaluateJavascript("(function(){try{return typeof window.onAndroidBack==='function'&&window.onAndroidBack()===true}catch(e){return false}})()",
                v -> {
                    if ("true".equals(v)) return;
                    if (web.canGoBack()) web.goBack(); else finish();
                });
    }

    @Override protected void onPause() { super.onPause(); web.onPause(); }
    @Override protected void onResume() { super.onResume(); web.onResume(); }

    // ---------- JS bridge ----------
    class Bridge {
        @JavascriptInterface
        public void saveFile(final String name, String mime, String base64) {
            final byte[] data = Base64.decode(base64, Base64.DEFAULT);
            final String m = (mime == null || mime.isEmpty()) ? "application/octet-stream" : mime.split(";")[0];
            runOnUiThread(() -> {
                pendingSaveData = data;
                Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType(m);
                i.putExtra(Intent.EXTRA_TITLE, name);
                try { startActivityForResult(i, REQ_SAVE); }
                catch (Exception e) { Toast.makeText(MainActivity.this, "ذخیره انجام نشد", Toast.LENGTH_SHORT).show(); }
            });
        }

        @JavascriptInterface
        public void print(final String title) {
            runOnUiThread(() -> {
                PrintManager pm = (PrintManager) getSystemService(Context.PRINT_SERVICE);
                String t = (title == null || title.isEmpty()) ? "document" : title;
                pm.print(t, web.createPrintDocumentAdapter(t), new PrintAttributes.Builder().build());
            });
        }

        @JavascriptInterface
        public void toast(final String msg) {
            runOnUiThread(() -> Toast.makeText(MainActivity.this, msg, Toast.LENGTH_SHORT).show());
        }

        @JavascriptInterface
        public void vibrate(String pattern) {
            try {
                String[] parts = pattern.split(",");
                long[] p = new long[parts.length + 1];
                p[0] = 0;
                for (int i = 0; i < parts.length; i++) p[i + 1] = Math.max(0, Long.parseLong(parts[i].trim()));
                Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                if (v == null) return;
                if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createWaveform(p, -1));
                else v.vibrate(p, -1);
            } catch (Exception ignored) { }
        }

        @JavascriptInterface
        public void copy(final String text) {
            runOnUiThread(() -> {
                ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                cm.setPrimaryClip(ClipData.newPlainText("text", text));
            });
        }

        @JavascriptInterface
        public String paste() {
            try {
                ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                if (cm.hasPrimaryClip() && cm.getPrimaryClip().getItemCount() > 0) {
                    CharSequence t = cm.getPrimaryClip().getItemAt(0).coerceToText(MainActivity.this);
                    return t == null ? "" : t.toString();
                }
            } catch (Exception ignored) { }
            return "";
        }

        @JavascriptInterface
        public void share(String title, String text, String url) {
            String body = ((text == null ? "" : text) + (url == null || url.isEmpty() ? "" : "\n" + url)).trim();
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType("text/plain");
            if (title != null && !title.isEmpty()) i.putExtra(Intent.EXTRA_SUBJECT, title);
            i.putExtra(Intent.EXTRA_TEXT, body);
            Intent c = Intent.createChooser(i, null);
            c.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            try { startActivity(c); } catch (Exception ignored) { }
        }

        @JavascriptInterface
        public void requestNotificationPermission() {
            if (Build.VERSION.SDK_INT >= 33) {
                runOnUiThread(() -> ensure(Arrays.asList(Manifest.permission.POST_NOTIFICATIONS), () -> { }));
            }
        }

        @JavascriptInterface
        public void notify(String title, String body) {
            Notifier.show(MainActivity.this, (int) (System.currentTimeMillis() % 100000), title, body);
        }

        @JavascriptInterface
        public void schedule(int id, String title, String body, long atMs) {
            Intent i = new Intent(MainActivity.this, AlarmReceiver.class);
            i.putExtra("id", id).putExtra("title", title).putExtra("body", body);
            int fl = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);
            PendingIntent pi = PendingIntent.getBroadcast(MainActivity.this, id, i, fl);
            AlarmManager am = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
            if (Build.VERSION.SDK_INT >= 23) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, atMs, pi);
            else am.set(AlarmManager.RTC_WAKEUP, atMs, pi);
        }

        @JavascriptInterface
        public void cancelSchedule(int id) {
            Intent i = new Intent(MainActivity.this, AlarmReceiver.class);
            int fl = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);
            PendingIntent pi = PendingIntent.getBroadcast(MainActivity.this, id, i, fl);
            ((AlarmManager) getSystemService(Context.ALARM_SERVICE)).cancel(pi);
        }

        @JavascriptInterface
        public void exitApp() { runOnUiThread(() -> finish()); }
    }
}
