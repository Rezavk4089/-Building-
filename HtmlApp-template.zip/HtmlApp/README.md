# HtmlApp template

1. Replace `app/src/main/assets/www/index.html` with your HTML file (keep the name index.html).
   Fonts/images/js next to it go in the same `www` folder.
2. App name: `app/src/main/res/values/strings.xml`
3. Icon: replace `app/src/main/res/mipmap-xxxhdpi/ic_launcher.png`
4. Unique app id: `applicationId` in `app/build.gradle`
5. Build: push to GitHub -> Actions -> "Build APK" -> download artifact `app-debug`.

`assets/bridge.js` is injected automatically and fixes downloads/backup, print,
notifications, clipboard, share and vibrate. In your HTML you can also call
`AppNative.saveText(name, text)` and `AppNative.schedule(id, title, body, date)`.
