/* Auto-injected into every page by the app. Replaces browser features that
   do not work inside an Android WebView with native versions.
   The HTML file itself needs no changes. */
(function () {
  if (window.__bridgeInstalled) return;
  window.__bridgeInstalled = true;
  function B() { return window.AndroidBridge; }

  /* ---- 1) Downloads / backups: <a download>, Blob, data: URLs, FileSaver.js ---- */
  var blobs = new Map();
  var _create = URL.createObjectURL.bind(URL);
  URL.createObjectURL = function (o) {
    var u = _create(o);
    if (o instanceof Blob) blobs.set(u, o);
    return u;
  };
  var _revoke = URL.revokeObjectURL.bind(URL);
  URL.revokeObjectURL = function (u) {
    setTimeout(function () { blobs.delete(u); }, 30000);
    try { _revoke(u); } catch (e) {}
  };
  function toB64(blob) {
    return new Promise(function (res, rej) {
      var r = new FileReader();
      r.onload = function () { var s = String(r.result); res(s.substring(s.indexOf(',') + 1)); };
      r.onerror = rej;
      r.readAsDataURL(blob);
    });
  }
  function saveBlob(blob, name) {
    return toB64(blob).then(function (b64) {
      B().saveFile(name || 'file', (blob.type || 'application/octet-stream').split(';')[0], b64);
    });
  }
  function handleDownload(href, name) {
    var p = blobs.has(href) ? Promise.resolve(blobs.get(href))
                            : fetch(href).then(function (r) { return r.blob(); });
    return p.then(function (b) { return saveBlob(b, name); })
            .catch(function () { B().toast('خطا در ذخیره فایل'); });
  }
  function isDl(a) { return a && a.tagName === 'A' && a.hasAttribute('download') && a.href; }
  function dlName(a) { return a.getAttribute('download') || 'download'; }

  var _aclick = HTMLAnchorElement.prototype.click;
  HTMLAnchorElement.prototype.click = function () {
    if (isDl(this)) { handleDownload(this.href, dlName(this)); return; }
    return _aclick.apply(this, arguments);
  };
  var _dispatch = EventTarget.prototype.dispatchEvent;
  EventTarget.prototype.dispatchEvent = function (ev) {
    if (ev && ev.type === 'click' && isDl(this)) { handleDownload(this.href, dlName(this)); return true; }
    return _dispatch.apply(this, arguments);
  };
  document.addEventListener('click', function (e) {
    var a = e.target && e.target.closest ? e.target.closest('a') : null;
    if (isDl(a)) { e.preventDefault(); e.stopPropagation(); handleDownload(a.href, dlName(a)); }
  }, true);

  /* ---- 2) Print / PDF ---- */
  window.print = function () { B().print(document.title || 'document'); };

  /* ---- 3) Notifications ---- */
  function NativeNotification(title, opts) {
    opts = opts || {};
    B().notify(String(title), String(opts.body || ''));
    this.close = function () {};
  }
  NativeNotification.permission = 'granted';
  NativeNotification.requestPermission = function (cb) {
    B().requestNotificationPermission();
    if (typeof cb === 'function') cb('granted');
    return Promise.resolve('granted');
  };
  window.Notification = NativeNotification;

  /* ---- 4) Clipboard / Share / Vibrate ---- */
  try {
    Object.defineProperty(navigator, 'clipboard', {
      configurable: true,
      value: {
        writeText: function (t) { B().copy(String(t)); return Promise.resolve(); },
        readText: function () { return Promise.resolve(B().paste()); }
      }
    });
  } catch (e) {}
  navigator.share = function (d) {
    d = d || {};
    if (d.files && d.files.length) return Promise.reject(new DOMException('Files not supported', 'NotAllowedError'));
    B().share(d.title || '', d.text || '', d.url || '');
    return Promise.resolve();
  };
  navigator.canShare = function (d) { return !(d && d.files && d.files.length); };
  navigator.vibrate = function (p) {
    B().vibrate(Array.isArray(p) ? p.join(',') : String(p));
    return true;
  };

  /* ---- 5) Helpers the page can call directly ---- */
  window.AppNative = {
    isApp: true,
    toast: function (m) { B().toast(String(m)); },
    // save any text (e.g. JSON backup) with a "Save as" dialog
    saveText: function (name, text, mime) {
      return saveBlob(new Blob([text], { type: mime || 'text/plain' }), name);
    },
    // schedule a notification that fires even when the app is closed
    schedule: function (id, title, body, date) {
      B().schedule(id | 0, String(title), String(body || ''), +new Date(date));
    },
    cancel: function (id) { B().cancelSchedule(id | 0); },
    exit: function () { B().exitApp(); }
  };
})();
