قالب اپ HTML به اندروید

اجرا:
1. Android Studio را باز کنید: File > Open و پوشه HtmlAppTemplate را انتخاب کنید.
2. صبر کنید Gradle Sync تمام شود (بار اول به اینترنت نیاز دارد).
3. گوشی را وصل کنید یا شبیه ساز بسازید و دکمه Run را بزنید.
4. صفحه تست اجرا می شود. پنج کارت آن را بررسی کنید.

برای تست HTML خودتان:
فایل خود را با نام index.html در app/src/main/assets/www/ جایگزین کنید.
اگر چند فایل دارد (css, js, font, image) همه را همان پوشه بگذارید.

ساخت APK:
Build > Build Bundle(s) / APK(s) > Build APK(s)
خروجی: app/build/outputs/apk/debug/app-debug.apk

نکته: فونت ها و کتابخانه ها را داخل پوشه www بگذارید و از CDN استفاده نکنید تا بدون اینترنت کار کند.
