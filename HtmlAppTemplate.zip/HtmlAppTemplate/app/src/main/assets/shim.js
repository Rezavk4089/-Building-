/* پل بین HTML و اندروید: چاپ، اشتراک، انتخاب مسیر ذخیره و باز کردن فایل */
(function(){
if(window.__shimOk)return;window.__shimOk=1;
window.__saveCb={};window.__openCb={};
window.print=function(){AndroidBridge.print();};
navigator.share=function(d){d=d||{};AndroidBridge.share([d.title,d.text,d.url].filter(Boolean).join('\n'));return Promise.resolve();};
navigator.canShare=function(){return true;};
function ab(s){var b=atob(s),u=new Uint8Array(b.length);for(var i=0;i<b.length;i++)u[i]=b.charCodeAt(i);return u;}
window.showSaveFilePicker=function(o){
  o=o||{};var name=o.suggestedName||'file',mime='application/octet-stream';
  try{mime=Object.keys(o.types[0].accept)[0];}catch(e){}
  return new Promise(function(res,rej){
    var id='s'+Date.now();
    __saveCb[id]=function(ok,nm){
      if(!ok)return rej(new DOMException('cancelled','AbortError'));
      res({kind:'file',name:nm,createWritable:function(){
        var parts=[];
        return Promise.resolve({
          write:function(d){if(d&&d.data!==undefined)d=d.data;parts.push(d instanceof Blob?d:new Blob([d]));return Promise.resolve();},
          close:function(){return new Promise(function(r){var f=new FileReader();f.onload=function(){AndroidBridge.writeSaved(id,String(f.result).split(',')[1]||'');r();};f.readAsDataURL(new Blob(parts,{type:mime}));});}
        });
      }});
    };
    AndroidBridge.pickSave(id,name,mime);
  });
};
window.showOpenFilePicker=function(){
  return new Promise(function(res,rej){
    var id='o'+Date.now();
    __openCb[id]=function(ok,nm,b64,mime){
      if(!ok)return rej(new DOMException('cancelled','AbortError'));
      var f=new File([ab(b64)],nm,{type:mime||''});
      res([{kind:'file',name:nm,getFile:function(){return Promise.resolve(f);}}]);
    };
    AndroidBridge.pickOpen(id);
  });
};
})();
