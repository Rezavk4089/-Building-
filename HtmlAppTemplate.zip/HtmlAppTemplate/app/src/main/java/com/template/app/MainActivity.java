package com.template.app;

import android.Manifest;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.print.PrintManager;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.util.Base64;
import android.view.WindowManager;
import android.webkit.*;
import android.widget.Toast;

import androidx.core.content.FileProvider;
import androidx.webkit.WebViewAssetLoader;
import androidx.webkit.WebViewCompat;
import androidx.webkit.WebViewFeature;

import org.json.JSONObject;

import java.io.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

/** قالب ثابت: HTML کاربر در assets/www است و با آدرس https داخلی اجرا می‌شود. */
public class MainActivity extends Activity {

    private static final String HOST = "appassets.androidplatform.net";
    private static final String HOME = "https://" + HOST + "/assets/www/index.html";
    private static final int REQ_FILE = 1, REQ_PERM = 2, REQ_CAM = 3, REQ_CAMPERM = 4,
            REQ_SAVE = 5, REQ_OPEN = 6, REQ_GEO = 7;

    private WebView web;
    private ValueCallback<Uri[]> fileCb;
    private Uri camUri;
    private Intent pendingCam;
    private PermissionRequest pendingPerm;
    private GeolocationPermissions.Callback geoCb;
    private String geoOrigin, pendId;
    private final HashMap<String, Uri> saves = new HashMap<>();

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);

        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this)).build();
        final String shim = readAsset("shim.js");

        web = new WebView(this);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setGeolocationEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        // ثابت ماندن ظاهر
        s.setTextZoom(100);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(false);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        if (android.os.Build.VERSION.SDK_INT >= 33) s.setAlgorithmicDarkeningAllowed(false);
        else if (android.os.Build.VERSION.SDK_INT >= 29) s.setForceDark(WebSettings.FORCE_DARK_OFF);

        web.addJavascriptInterface(new Bridge(), "AndroidBridge");
        final boolean docStart = WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT);
        if (docStart)
            WebViewCompat.addDocumentStartJavaScript(web, shim, Collections.singleton("https://" + HOST));

        web.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                return loader.shouldInterceptRequest(r.getUrl());
            }
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if (HOST.equals(u.getHost())) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception ignored) {}
                return true;
            }
            @Override public void onPageFinished(WebView v, String u) {
                if (!docStart) v.evaluateJavascript(shim, null);
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (fileCb != null) fileCb.onReceiveValue(null);
                fileCb = cb;
                String[] a = p.getAcceptTypes();
                String type = (a.length > 0 && a[0] != null) ? a[0] : "";
                try {
                    if (p.isCaptureEnabled() && (type.startsWith("image") || type.startsWith("video"))) {
                        boolean vid = type.startsWith("video");
                        File d = new File(getCacheDir(), "cam"); d.mkdirs();
                        File f = File.createTempFile(vid ? "vid" : "img", vid ? ".mp4" : ".jpg", d);
                        camUri = FileProvider.getUriForFile(MainActivity.this, getPackageName() + ".fp", f);
                        Intent ci = new Intent(vid ? MediaStore.ACTION_VIDEO_CAPTURE : MediaStore.ACTION_IMAGE_CAPTURE)
                                .putExtra(MediaStore.EXTRA_OUTPUT, camUri)
                                .addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                            pendingCam = ci;
                            requestPermissions(new String[]{Manifest.permission.CAMERA}, REQ_CAMPERM);
                        } else startActivityForResult(ci, REQ_CAM);
                    } else startActivityForResult(p.createIntent(), REQ_FILE);
                    return true;
                } catch (Exception e) { fileCb = null; return false; }
            }

            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(() -> {
                    List<String> need = new ArrayList<>();
                    for (String res : request.getResources()) {
                        String p = null;
                        if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(res)) p = Manifest.permission.CAMERA;
                        if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(res)) p = Manifest.permission.RECORD_AUDIO;
                        if (p != null && checkSelfPermission(p) != PackageManager.PERMISSION_GRANTED) need.add(p);
                    }
                    if (need.isEmpty()) request.grant(request.getResources());
                    else { pendingPerm = request; requestPermissions(need.toArray(new String[0]), REQ_PERM); }
                });
            }

            @Override
            public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback cb) {
                if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED)
                    cb.invoke(origin, true, false);
                else {
                    geoCb = cb; geoOrigin = origin;
                    requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQ_GEO);
                }
            }

            @Override public boolean onJsAlert(WebView v, String url, String msg, JsResult r) {
                new android.app.AlertDialog.Builder(MainActivity.this).setMessage(msg)
                        .setPositiveButton("باشه", (d, i) -> r.confirm()).setOnCancelListener(d -> r.cancel()).show();
                return true;
            }
            @Override public boolean onJsConfirm(WebView v, String url, String msg, JsResult r) {
                new android.app.AlertDialog.Builder(MainActivity.this).setMessage(msg)
                        .setPositiveButton("تایید", (d, i) -> r.confirm())
                        .setNegativeButton("لغو", (d, i) -> r.cancel())
                        .setOnCancelListener(d -> r.cancel()).show();
                return true;
            }
            @Override public boolean onJsPrompt(WebView v, String url, String msg, String def, JsPromptResult r) {
                final android.widget.EditText et = new android.widget.EditText(MainActivity.this);
                et.setText(def);
                new android.app.AlertDialog.Builder(MainActivity.this).setMessage(msg).setView(et)
                        .setPositiveButton("تایید", (d, i) -> r.confirm(et.getText().toString()))
                        .setNegativeButton("لغو", (d, i) -> r.cancel())
                        .setOnCancelListener(d -> r.cancel()).show();
                return true;
            }
        });

        web.setDownloadListener((url, ua, cd, mime, len) -> {
            if (url.startsWith("data:")) {
                saveBase64(url.substring(url.indexOf(",") + 1), URLUtil.guessFileName(url, cd, mime));
            } else if (url.startsWith("blob:")) {
                web.evaluateJavascript("fetch('" + url + "').then(r=>r.blob()).then(b=>{var f=new FileReader();"
                        + "f.onload=()=>AndroidBridge.saveFile(f.result.split(',')[1],'" + mime + "');"
                        + "f.readAsDataURL(b);});", null);
            }
        });

        if (b == null) web.loadUrl(HOME); else web.restoreState(b);
    }

    /* ---------- پل جاوااسکریپت ---------- */
    class Bridge {
        @JavascriptInterface public void saveFile(String base64, String mime) {
            String ext = MimeTypeMap.getSingleton().getExtensionFromMimeType(mime);
            saveBase64(base64, "file_" + System.currentTimeMillis() + "." + (ext == null ? "bin" : ext));
        }
        @JavascriptInterface public void print() {
            runOnUiThread(() -> ((PrintManager) getSystemService(PRINT_SERVICE))
                    .print("document", web.createPrintDocumentAdapter("document"), null));
        }
        @JavascriptInterface public void share(String t) {
            runOnUiThread(() -> startActivity(Intent.createChooser(
                    new Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, t), null)));
        }
        @JavascriptInterface public void pickSave(String id, String name, String mime) {
            runOnUiThread(() -> {
                pendId = id;
                startActivityForResult(new Intent(Intent.ACTION_CREATE_DOCUMENT)
                        .addCategory(Intent.CATEGORY_OPENABLE).setType(mime)
                        .putExtra(Intent.EXTRA_TITLE, name), REQ_SAVE);
            });
        }
        @JavascriptInterface public void writeSaved(String id, String b64) {
            Uri u = saves.get(id);
            if (u == null) return;
            try (OutputStream o = getContentResolver().openOutputStream(u, "wt")) {
                o.write(Base64.decode(b64, Base64.DEFAULT));
                toast("ذخیره شد");
            } catch (Exception e) { toast("ذخیره نشد"); }
        }
        @JavascriptInterface public void pickOpen(String id) {
            runOnUiThread(() -> {
                pendId = id;
                startActivityForResult(new Intent(Intent.ACTION_OPEN_DOCUMENT)
                        .addCategory(Intent.CATEGORY_OPENABLE).setType("*/*"), REQ_OPEN);
            });
        }
    }

    /* ---------- نتایج ---------- */
    @Override
    protected void onActivityResult(int req, int res, Intent d) {
        super.onActivityResult(req, res, d);
        Uri u = (res == RESULT_OK && d != null) ? d.getData() : null;
        if (req == REQ_FILE && fileCb != null) {
            fileCb.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, d)); fileCb = null;
        } else if (req == REQ_CAM && fileCb != null) {
            fileCb.onReceiveValue(res == RESULT_OK ? new Uri[]{camUri} : null); fileCb = null;
        } else if (req == REQ_SAVE) {
            if (u != null) {
                saves.put(pendId, u);
                js("__saveCb['" + pendId + "'](true," + JSONObject.quote(name(u)) + ")");
            } else js("__saveCb['" + pendId + "'](false)");
        } else if (req == REQ_OPEN) {
            if (u == null) { js("__openCb['" + pendId + "'](false)"); return; }
            try (InputStream in = getContentResolver().openInputStream(u);
                 ByteArrayOutputStream o = new ByteArrayOutputStream()) {
                byte[] buf = new byte[8192]; int r;
                while ((r = in.read(buf)) > 0) o.write(buf, 0, r);
                js("__openCb['" + pendId + "'](true," + JSONObject.quote(name(u)) + ",'"
                        + Base64.encodeToString(o.toByteArray(), Base64.NO_WRAP) + "',"
                        + JSONObject.quote(String.valueOf(getContentResolver().getType(u))) + ")");
            } catch (Exception e) { js("__openCb['" + pendId + "'](false)"); }
        }
    }

    @Override
    public void onRequestPermissionsResult(int req, String[] perms, int[] results) {
        super.onRequestPermissionsResult(req, perms, results);
        boolean ok = results.length > 0;
        for (int r : results) if (r != PackageManager.PERMISSION_GRANTED) ok = false;
        if (req == REQ_PERM && pendingPerm != null) {
            if (ok) pendingPerm.grant(pendingPerm.getResources()); else pendingPerm.deny();
            pendingPerm = null;
        } else if (req == REQ_CAMPERM) {
            if (ok && pendingCam != null) startActivityForResult(pendingCam, REQ_CAM);
            else if (fileCb != null) { fileCb.onReceiveValue(null); fileCb = null; }
            pendingCam = null;
        } else if (req == REQ_GEO && geoCb != null) {
            geoCb.invoke(geoOrigin, ok, false); geoCb = null;
        }
    }

    /* ---------- ابزارها ---------- */
    private void js(final String code) { runOnUiThread(() -> web.evaluateJavascript(code, null)); }
    private void toast(final String m) { runOnUiThread(() -> Toast.makeText(this, m, Toast.LENGTH_LONG).show()); }

    private String name(Uri u) {
        try (Cursor c = getContentResolver().query(u, null, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (i >= 0) return c.getString(i);
            }
        } catch (Exception ignored) {}
        return "file";
    }

    private String readAsset(String n) {
        try (InputStream in = getAssets().open(n); ByteArrayOutputStream o = new ByteArrayOutputStream()) {
            byte[] b = new byte[4096]; int r;
            while ((r = in.read(b)) > 0) o.write(b, 0, r);
            return o.toString("UTF-8");
        } catch (Exception e) { return ""; }
    }

    private void saveBase64(String data, String name) {
        try {
            byte[] bytes = Base64.decode(data, Base64.DEFAULT);
            if (android.os.Build.VERSION.SDK_INT >= 29) {
                ContentValues v = new ContentValues();
                v.put(MediaStore.Downloads.DISPLAY_NAME, name);
                Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                try (OutputStream o = getContentResolver().openOutputStream(uri)) { o.write(bytes); }
            } else {
                if (checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                    runOnUiThread(() -> requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 9));
                    toast("اجازه ذخیره را بدهید و دوباره تلاش کنید");
                    return;
                }
                File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                try (FileOutputStream o = new FileOutputStream(new File(dir, name))) { o.write(bytes); }
            }
            toast("ذخیره شد در Downloads: " + name);
        } catch (Exception e) { toast("ذخیره نشد"); }
    }

    @Override public void onBackPressed() { if (web.canGoBack()) web.goBack(); else super.onBackPressed(); }
    @Override protected void onSaveInstanceState(Bundle o) { super.onSaveInstanceState(o); web.saveState(o); }
    @Override protected void onPause() { super.onPause(); web.onPause(); CookieManager.getInstance().flush(); }
    @Override protected void onResume() { super.onResume(); web.onResume(); }
}
